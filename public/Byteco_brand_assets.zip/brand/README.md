# Byteco Brand Asset Guidlines

If you are using the Byteco logo, please take note that there are two versions. One for smaller applications, one for larger. If you are using the logo at a size less than 36x36px. Please choose the smaller size.

Our main brand color is #FF007A.
